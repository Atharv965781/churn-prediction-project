# Customer Churn Prediction Project

This project includes training scripts, prediction API, and a Streamlit dashboard.
